import os
import json
import time
import random
import boto3
from datetime import datetime, timedelta

kinesis_firehose = boto3.client('kinesis')
STREAM_NAME = os.environ['KINESIS_FIREHOSE_STREAM_NAME']

def generate_dummy_data():
    data = {
        'speed': round(random.uniform(200, 350), 2), # Speed in km/h
        'engine_temperature': round(random.uniform(80, 120), 2), # Engine temperature in Celsius
        'tire_pressure': round(random.uniform(15, 25), 2), # Tire pressure in psi
        'fuel_level': round(random.uniform(0, 100), 2) # Fuel level as a percentage
    }
    return data

def send_data_to_firehose(data):
    data_str = json.dumps(data)
    kinesis_firehose.put_record(
        StreamName=STREAM_NAME,
        Data=data_str,
        PartitionKey=str(hash(data_str))  # You can use any method to create a partition key
    )

def lambda_handler(event, context):
    end_time = datetime.now() + timedelta(minutes=15)
    while datetime.now() < end_time:
        dummy_data = generate_dummy_data()
        for _ in range(250):  # Send data 250 times per second to achieve 1MB per second
            send_data_to_firehose(dummy_data)
        time.sleep(1)  # Send data every second
